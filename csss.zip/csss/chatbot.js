// Chatbot functionality
function toggleChatbot() {
    const chatbotWindow = document.querySelector('.chatbot-window');
    chatbotWindow.classList.toggle('active');
}

function sendMessage() {
    const input = document.getElementById('chatbotInput');
    const message = input.value.trim();

    if (!message) return;

    addMessage(message, 'user');
    input.value = '';

    const typingMsgId = addMessage("Bot is typing...", 'bot', true);

    setTimeout(async () => {
        const typingMsg = document.getElementById(typingMsgId);
        if (typingMsg) typingMsg.remove();

        const botResponse = await getBotResponse(message);
        addMessage(botResponse, 'bot');
    }, 1000);
}

function addMessage(message, sender, isTyping = false) {
    const messagesContainer = document.getElementById('chatbotMessages');
    const messageDiv = document.createElement('div');
    const uniqueId = `msg-${Date.now()}`;

    messageDiv.className = `chatbot-message ${sender}`;
    messageDiv.id = isTyping ? uniqueId : '';

    const messageText = document.createElement('p');
    messageText.textContent = message;
    messageDiv.appendChild(messageText);

    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    return uniqueId;
}

async function getBotResponse(message) {
    const lowerMessage = message.toLowerCase();

    const locationMap = {
        'gachibowli': 'Gachibowli',
        'shamshabad': 'Shamshabad',
        'kukatpally': 'Kukatpally',
        'mallapur': 'Mallapur',
        'hi tech city': 'Hi Tech City',
        'manikonda': 'Manikonda',
        'lb nagar': 'LB Nagar',
        'hayathnagar': 'Hayathnagar',
        'habsiguda': 'Habsiguda',
        'jubilee hills': 'Jubilee Hills',
        'banjara hills': 'Banjara Hills',
        'secunderabad': 'Secunderabad'
    };

    const isVenture = lowerMessage.includes('venture');

    for (let key in locationMap) {
        if (lowerMessage.includes(key)) {
            const location = locationMap[key];
            const url = isVenture
                ? `ventures.php?location=${encodeURIComponent(location)}`
                : `properties.php?location=${encodeURIComponent(location)}`;

            try {
                const response = await fetch(url);
                if (!response.ok) throw new Error('API failed');

                const data = await response.json();
                if (data.length > 0) {
                    if (isVenture) {
                        return `🌄 Ventures in ${location}:\n` +
                            data.map(v => `• ${v.title || 'No title'} - ${v.venture_type || 'Unknown type'}`).join('\n');
                    } else {
                        return `🏠 Properties in ${location}:\n` +
                            data.map(p => `• ${p.title || 'No title'} - ₹${p.price || 'N/A'} - ${p.property_type || 'N/A'}`).join('\n');
                    }
                } else {
                    return `Sorry, no ${isVenture ? 'ventures' : 'properties'} found in ${location}.`;
                }
            } catch (err) {
                return `⚠️ Failed to fetch ${isVenture ? 'venture' : 'property'} details.`;
            }
        }
    }

    // Static fallback responses
    if (lowerMessage.includes('hello') || lowerMessage.includes('hi')) {
        return "Hello! 👋 How can I assist with your real estate needs?";
    } else if (lowerMessage.includes('property') || lowerMessage.includes('house')) {
        return "Sure! Please tell me which area you're interested in.";
    } else if (lowerMessage.includes('price') || lowerMessage.includes('cost')) {
        return "Prices depend on area and type. What’s your budget or preferred location?";
    } else if (lowerMessage.includes('location') || lowerMessage.includes('area')) {
        return "We serve areas like Gachibowli, Shamshabad, Kukatpally, Mallapur, Hi Tech City, Manikonda, LB Nagar, Hayathnagar, Habsiguda, Jubilee Hills, Banjara Hills, and Secunderabad. Which one would you prefer?";
    } else if (lowerMessage.includes('thank') || lowerMessage.includes('thanks')) {
        return "You're welcome! 😊 Feel free to ask about properties or ventures.";
    } else {
        return "🤖 I'm here to help! Please mention the area or venture/property you're looking for.";
    }
}

// Enter key support
document.getElementById('chatbotInput').addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
        sendMessage();
    }
});

// Send button support
document.getElementById('chatbotSendBtn').addEventListener('click', sendMessage);
