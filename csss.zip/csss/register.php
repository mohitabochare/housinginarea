<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Log file setup
$log_file = 'register_errors.log';
ini_set('error_log', $log_file);

try {
    // Get raw POST data
    $data = json_decode(file_get_contents('php://input'), true);
    error_log("Registration attempt - Raw POST data: " . file_get_contents('php://input'));

    if (!$data) {
        throw new Exception('No data received');
    }

    // Extract form data
    $fullname = $data['fullname'] ?? '';
    $email = $data['email'] ?? '';
    $phone = $data['phone'] ?? '';
    $password = $data['password'] ?? '';

    // Validate input
    if (empty($fullname) || empty($email) || empty($phone) || empty($password)) {
        throw new Exception('All fields are required');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Invalid email format');
    }

    // Connect to database
    $conn = new mysqli('localhost', 'root', '', 'real');
    
    if ($conn->connect_error) {
        error_log("Database connection error: " . $conn->connect_error);
        throw new Exception('Database connection failed');
    }

    // Check if email already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        throw new Exception('Email already registered');
    }

    // Insert new user
    $stmt = $conn->prepare("INSERT INTO users (fullname, email, phone, password) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $fullname, $email, $phone, $password);

    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'message' => 'Registration successful!',
            'redirect' => 'login.html'
        ]);
    } else {
        error_log("Registration error: " . $stmt->error);
        throw new Exception('Registration failed. Please try again.');
    }

    $stmt->close();
    $conn->close();

} catch (Exception $e) {
    error_log("Registration error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?> 