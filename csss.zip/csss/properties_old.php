<?php

include 'database.php'; // Ensure this file exists in the same folder

header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT * FROM properties");
    $properties = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($properties);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}

?>