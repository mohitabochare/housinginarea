<?php
header('Content-Type: application/json');

$host = 'localhost';
$dbname = 'real'; 
$username = 'root'; 
$password = ''; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Base query to get properties
    $query = "SELECT * FROM properties WHERE 1=1";
    $params = [];

    if (isset($_GET['location']) && $_GET['location'] != '') {
        $query .= " AND location = :location";
        $params[':location'] = $_GET['location'];
    }

    if (isset($_GET['property_type']) && $_GET['property_type'] != '') {
        $query .= " AND property_type = :property_type";
        $params[':property_type'] = $_GET['property_type'];
    }

    if (isset($_GET['transaction_type']) && $_GET['transaction_type'] != '') {
        $query .= " AND transaction_type = :transaction_type";
        $params[':transaction_type'] = $_GET['transaction_type'];
    }

    if (isset($_GET['budget']) && $_GET['budget'] != '') {
        list($minPrice, $maxPrice) = explode('-', $_GET['budget']);
        $query .= " AND price BETWEEN :minPrice AND :maxPrice";
        $params[':minPrice'] = $minPrice;
        $params[':maxPrice'] = $maxPrice;
    }

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $properties = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch images for each property
    foreach ($properties as &$property) {
        $stmtImages = $pdo->prepare("SELECT url FROM property_images WHERE property_id = ?");
        $stmtImages->execute([$property['id']]);
        $property['images'] = $stmtImages->fetchAll(PDO::FETCH_COLUMN); // Fetch as array of URLs
    }

    echo json_encode($properties);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>