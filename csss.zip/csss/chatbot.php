<?php
header('Content-Type: application/json');

$host = 'localhost';
$dbname = 'real';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $input = strtolower($_POST['message'] ?? '');

    $response = "Sorry, I didn't understand that.";

    // Check for property-related queries
    if (strpos($input, 'property') !== false || strpos($input, 'properties') !== false) {
        // Extract location if mentioned
        if (preg_match('/in\s+([a-zA-Z\s]+)/', $input, $matches)) {
            $location = trim($matches[1]);
            $stmt = $pdo->prepare("SELECT title, price FROM properties WHERE location LIKE ?");
            $stmt->execute(["%$location%"]);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if ($results) {
                $response = "Here are properties in $location:\n";
                foreach ($results as $r) {
                    $response .= "🏠 {$r['title']} – ₹" . number_format($r['price']) . "\n";
                }
            } else {
                $response = "No properties found in $location.";
            }
        } else {
            $response = "Please specify a location. Example: 'Show me properties in Gachibowli'";
        }
    }

    // Check for venture-related queries
    elseif (strpos($input, 'venture') !== false || strpos($input, 'ventures') !== false) {
        if (preg_match('/in\s+([a-zA-Z\s]+)/', $input, $matches)) {
            $location = trim($matches[1]);
            $stmt = $pdo->prepare("SELECT title, price FROM ventures WHERE location LIKE ?");
            $stmt->execute(["%$location%"]);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if ($results) {
                $response = "Ventures in $location:\n";
                foreach ($results as $r) {
                    $response .= "🌐 {$r['title']} – ₹" . number_format($r['price']) . "\n";
                }
            } else {
                $response = "No ventures found in $location.";
            }
        } else {
            $response = "Please mention a location. Example: 'What ventures are in Kondapur'";
        }
    }

    echo json_encode(['reply' => nl2br($response)]);

} catch (PDOException $e) {
    echo json_encode(['reply' => 'Database error: ' . $e->getMessage()]);
}
?>
