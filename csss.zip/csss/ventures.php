<?php
header('Content-Type: application/json');

$host = 'localhost';
$dbname = 'real'; // Ensure this matches your actual database name
$username = 'root'; // Default XAMPP username
$password = ''; // Default XAMPP password is empty

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Start building the SQL query with base condition
    $query = "SELECT * FROM ventures WHERE 1=1"; // default to fetch all ventures
    $params = [];

    // Apply filters for location and venture type
    if (isset($_GET['venture_type']) && $_GET['venture_type'] != '') {
        $query .= " AND venture_type = :venture_type";
        $params[':venture_type'] = $_GET['venture_type'];
    }

    if (isset($_GET['location']) && $_GET['location'] != '') {
        $query .= " AND location = :location";
        $params[':location'] = $_GET['location'];
    }

    // Execute the query
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $ventures = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($ventures);

} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>