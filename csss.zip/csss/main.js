// Global Variables
const API_BASE_URL = 'http://localhost/real';
let currentUser = null;

// Debugging
console.log('JavaScript loaded');

// Initialize Application
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded');
    initializeApp();
});

async function initializeApp() {
    setupEventListeners();
    await loadInitialProperties();
    await loadVentures();
}

// Event Listeners
function setupEventListeners() {
    const menuBtn = document.querySelector('.menu-btn');
    const navLinks = document.querySelector('.nav-links');
    
    menuBtn?.addEventListener('click', () => {
        navLinks.classList.toggle('active');
    });

    const searchBtn = document.querySelector('.search-btn');
    if (searchBtn) {
        searchBtn.addEventListener('click', loadInitialProperties);
    }

    const ventureSearchBtn = document.querySelector('.venture-search-btn');
    if (ventureSearchBtn) {
        ventureSearchBtn.addEventListener('click', loadVentures);
    }
}

// Fetch and Display Properties
async function loadInitialProperties() {
    try {
        const location = document.getElementById('location').value;
        const propertyType = document.getElementById('propertyType').value;
        const transactionType = document.getElementById('transactionType').value;
        const budget = document.getElementById('budget').value;

        const filters = [];
        if (location) filters.push('location=' + encodeURIComponent(location));
        if (propertyType) filters.push('property_type=' + encodeURIComponent(propertyType));
        if (transactionType) filters.push('transaction_type=' + encodeURIComponent(transactionType));
        if (budget) filters.push('budget=' + encodeURIComponent(budget));

        const queryString = filters.length > 0 ? ('?' + filters.join('&')) : '';
        const response = await fetch(`${API_BASE_URL}/properties.php${queryString}`);
        if (!response.ok) throw new Error('Failed to fetch properties');

        const data = await response.json();
        displayProperties(data);
    } catch (error) {
        console.error('Error loading properties:', error);
        displayProperties([]);
    }
}

function displayProperties(properties) {
    const propertyGrid = document.getElementById('propertyGrid');
    if (!propertyGrid) return;

    if (!properties || properties.length === 0) {
        propertyGrid.innerHTML = `
            <div class="no-properties">
                <i class='bx bx-search-alt'></i>
                <h3>No Properties Found</h3>
            </div>
        `;
        return;
    }

    propertyGrid.innerHTML = properties.map((property, index) => {
        const firstImage = property.images && property.images.length > 0 ? property.images[0] : 'https://via.placeholder.com/400x300?text=No+Image';
        return `
            <div class="property-card" data-aos="fade-up" data-aos-delay="${index * 100}">
                <a href="property.html?id=${property.id}">
                    <div class="property-image" style="background-image: url('${firstImage}')">
                        <span class="property-tag">${property.transaction_type}</span>
                    </div>
                </a>
                <div class="property-info">
                    <h3>${property.title}</h3>
                    <p><i class='bx bxs-map'></i> ${property.location}</p>
                    <p>Price: ₹${parseFloat(property.price).toLocaleString('en-IN')}</p>
                    <a href="property.html?id=${property.id}" class="details-btn">View Details</a>
                </div>
            </div>
        `;
    }).join('');
}

// Fetch and Display Ventures
async function loadVentures() {
    try {
        const ventureType = document.getElementById('ventureType').value;
        const location = document.getElementById('ventureLocation').value;

        const filters = [];
        if (ventureType) filters.push('venture_type=' + encodeURIComponent(ventureType));
        if (location) filters.push('location=' + encodeURIComponent(location));

        const queryString = filters.length > 0 ? ('?' + filters.join('&')) : '';
        const response = await fetch(`${API_BASE_URL}/ventures.php${queryString}`);
        if (!response.ok) throw new Error('Failed to fetch ventures');

        const data = await response.json();
        displayVentures(data);
    } catch (error) {
        console.error('Error loading ventures:', error);
        displayVentures([]);
    }
}

function displayVentures(ventures) {
    const venturesGrid = document.getElementById('venturesGrid');
    if (!venturesGrid) return;

    if (!ventures || ventures.length === 0) {
        venturesGrid.innerHTML = `
            <div class="no-ventures">
                <i class='bx bx-search-alt'></i>
                <h3>No Ventures Found</h3>
            </div>
        `;
        return;
    }

    venturesGrid.innerHTML = ventures.map((venture, index) => `
        <div class="venture-card" data-aos="fade-up" data-aos-delay="${index * 100}">
            <div class="venture-image" style="background-image: url('${venture.image_url || 'https://via.placeholder.com/400x300?text=No+Image'}')">
                <span class="venture-tag">${venture.venture_type}</span>
            </div>
            <div class="venture-details">
                <h3>${venture.title}</h3>
                <p><i class='bx bxs-map'></i> ${venture.location}</p>
                <p>Price: ₹${parseFloat(venture.price).toLocaleString('en-IN')}</p>
                <button onclick="viewVentureDetails(${venture.id})">View Details</button>
            </div>
        </div>
    `).join('');
}

// View details of a single venture
async function viewVentureDetails(ventureId) {
    try {
        const response = await fetch(`${API_BASE_URL}/ventures.php?id=${ventureId}`);
        if (!response.ok) throw new Error('Failed to fetch venture details');

        const venture = await response.json();
        alert(Venture: ${venture.title}\nLocation: ${venture.location}\nPrice: ₹${venture.price});
    } catch (error) {
        console.error('Error loading venture details:', error);
    }
}