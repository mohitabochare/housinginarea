// EMI Calculator functionality
function calculateEMI() {
    const principal = parseFloat(document.getElementById('principal').value);
    const interest = parseFloat(document.getElementById('interest').value);
    const tenure = parseFloat(document.getElementById('tenure').value);

    if (isNaN(principal) || isNaN(interest) || isNaN(tenure)) {
        alert('Please enter valid numbers for all fields');
        return;
    }

    // Convert annual interest rate to monthly and percentage to decimal
    const monthlyInterest = (interest / 12) / 100;
    const numberOfPayments = tenure * 12;

    // Calculate EMI using the formula
    const emi = principal * monthlyInterest * Math.pow(1 + monthlyInterest, numberOfPayments) / 
                (Math.pow(1 + monthlyInterest, numberOfPayments) - 1);

    // Calculate total payment and interest
    const totalPayment = emi * numberOfPayments;
    const totalInterest = totalPayment - principal;

    // Display results
    document.getElementById('monthlyEMI').textContent = formatCurrency(emi);
    document.getElementById('totalInterest').textContent = formatCurrency(totalInterest);
    document.getElementById('totalPayment').textContent = formatCurrency(totalPayment);

    // Generate payment schedule
    generatePaymentSchedule(principal, monthlyInterest, emi, numberOfPayments);
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 0
    }).format(amount);
}

function generatePaymentSchedule(principal, monthlyRate, emi, numberOfPayments) {
    let remainingPrincipal = principal;
    const scheduleTable = document.getElementById('paymentSchedule');
    scheduleTable.innerHTML = '';

    for (let i = 1; i <= numberOfPayments; i++) {
        const interestPayment = remainingPrincipal * monthlyRate;
        const principalPayment = emi - interestPayment;
        remainingPrincipal -= principalPayment;

        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${i}</td>
            <td>${formatCurrency(principalPayment)}</td>
            <td>${formatCurrency(interestPayment)}</td>
            <td>${formatCurrency(remainingPrincipal)}</td>
        `;
        scheduleTable.appendChild(row);

        // Break if remaining principal is very small
        if (remainingPrincipal < 1) break;
    }
}

// Toggle EMI calculator visibility
function toggleEMICalculator() {
    const calculator = document.getElementById('emiCalculator');
    if (calculator) {
        calculator.classList.toggle('active');
        
        // Add overlay when calculator is active
        const overlay = document.createElement('div');
        overlay.className = 'calculator-overlay';
        overlay.onclick = toggleEMICalculator;
        
        if (calculator.classList.contains('active')) {
            document.body.appendChild(overlay);
            document.body.style.overflow = 'hidden'; // Prevent scrolling when calculator is open
        } else {
            const existingOverlay = document.querySelector('.calculator-overlay');
            if (existingOverlay) {
                existingOverlay.remove();
            }
            document.body.style.overflow = ''; // Restore scrolling
        }
    }
}

// Close calculator when clicking outside
document.addEventListener('click', function(event) {
    const calculator = document.getElementById('emiCalculator');
    const calculatorBtn = document.querySelector('.emi-calculator-btn');
    
    if (calculator && calculator.classList.contains('active') && 
        !calculator.contains(event.target) && 
        !calculatorBtn.contains(event.target)) {
        toggleEMICalculator();
    }
});

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('emi-calculator-form');
    const resultSection = document.getElementById('calculator-result');
    const scheduleTable = document.getElementById('payment-schedule-table');

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get input values
        const loanAmount = parseFloat(document.getElementById('loan-amount').value);
        const interestRate = parseFloat(document.getElementById('interest-rate').value);
        const loanTenure = parseInt(document.getElementById('loan-tenure').value);

        // Validate inputs
        if (isNaN(loanAmount) || isNaN(interestRate) || isNaN(loanTenure)) {
            alert('Please enter valid numbers for all fields');
            return;
        }

        // Calculate EMI
        const monthlyInterestRate = (interestRate / 100) / 12;
        const numberOfPayments = loanTenure * 12;
        
        const emi = loanAmount * monthlyInterestRate * 
                   Math.pow(1 + monthlyInterestRate, numberOfPayments) / 
                   (Math.pow(1 + monthlyInterestRate, numberOfPayments) - 1);

        const totalPayment = emi * numberOfPayments;
        const totalInterest = totalPayment - loanAmount;

        // Update result display
        document.getElementById('monthly-emi').textContent = formatCurrency(emi);
        document.getElementById('total-interest').textContent = formatCurrency(totalInterest);
        document.getElementById('total-payment').textContent = formatCurrency(totalPayment);

        // Generate payment schedule
        generatePaymentSchedule(loanAmount, monthlyInterestRate, emi, numberOfPayments);

        // Show results
        resultSection.style.display = 'block';
    });

    function formatCurrency(amount) {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            maximumFractionDigits: 0
        }).format(amount);
    }

    function generatePaymentSchedule(principal, monthlyRate, emi, numberOfPayments) {
        let remainingPrincipal = principal;
        let scheduleHTML = '';

        // Clear existing table body
        scheduleTable.innerHTML = '';

        for (let i = 1; i <= numberOfPayments; i++) {
            const interestPayment = remainingPrincipal * monthlyRate;
            const principalPayment = emi - interestPayment;
            remainingPrincipal -= principalPayment;

            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${i}</td>
                <td>${formatCurrency(principalPayment)}</td>
                <td>${formatCurrency(interestPayment)}</td>
                <td>${formatCurrency(remainingPrincipal)}</td>
            `;
            scheduleTable.appendChild(row);

            // Break if remaining principal is very small
            if (remainingPrincipal < 1) break;
        }
    }
}); 