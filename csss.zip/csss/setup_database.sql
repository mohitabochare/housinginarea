-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS `real`;

-- Use the database
USE `real`;

-- Create users table
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `fullname` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NOT NULL UNIQUE,
    `phone` VARCHAR(20) NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert a test user (password: test123)
INSERT INTO `users` (`fullname`, `email`, `phone`, `password`) 
VALUES ('Test User', 'test@example.com', '1234567890', 'test123')
ON DUPLICATE KEY UPDATE `email` = VALUES(`email`); 