<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    // Test database connection
    $conn = new mysqli('localhost', 'root', '', 'real');
    
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
    
    echo "Database connection successful!<br>";
    
    // Check if users table exists
    $result = $conn->query("SHOW TABLES LIKE 'users'");
    if ($result->num_rows == 0) {
        throw new Exception("Users table does not exist!");
    }
    
    echo "Users table exists!<br>";
    
    // Check if test user exists
    $result = $conn->query("SELECT * FROM users WHERE email = 'test@example.com'");
    if ($result->num_rows == 0) {
        throw new Exception("Test user does not exist!");
    }
    
    echo "Test user exists!<br>";
    
    $conn->close();
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?> 