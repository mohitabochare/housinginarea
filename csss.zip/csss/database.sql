-- Create database if not exists
CREATE DATABASE IF NOT EXISTS real;
USE real;

-- Create properties table with image_url column
CREATE TABLE IF NOT EXISTS properties (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(12,2) NOT NULL,
    location VARCHAR(100),
    property_type VARCHAR(50),
    transaction_type VARCHAR(20),
    area_size DECIMAL(10,2),
    bedrooms INT,
    bathrooms DECIMAL(4,1),
    is_featured BOOLEAN DEFAULT FALSE,
    image_url VARCHAR(255) NOT NULL,  -- Added column for image storage
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create property_images table for multiple images
CREATE TABLE IF NOT EXISTS property_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    property_id INT,
    url VARCHAR(500),
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE
);

-- Create ventures table
CREATE TABLE IF NOT EXISTS ventures (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    location VARCHAR(100),
    venture_type VARCHAR(50),
    price DECIMAL(12, 2),
    area_size DECIMAL(10, 2),
    image_url VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample properties with locations and images
INSERT INTO properties (
    title, description, price, location, property_type, 
    transaction_type, area_size, bedrooms, bathrooms, is_featured, image_url
) VALUES 
-- Gachibowli Properties
('Modern Apartment in Gachibowli', 
 'Spacious 3BHK apartment in gated community near Microsoft', 
 15000000, 'Gachibowli', 'Apartment', 'Buy', 2200, 3, 3, true, 'assets/images/properties/gachibowli1.jpg'),

-- Shamshabad Properties
('Premium Plot in Shamshabad', 
 'HMDA approved plot near airport', 
 5000000, 'Shamshabad', 'Plot', 'Sell', 2400, NULL, NULL, false, 'assets/images/properties/shamshabad1.jpg'),

-- Kukatpally Properties
('Family Home in Kukatpally', 
 'Spacious 4BHK house near JNTU', 
 18000000, 'Kukatpally', 'House', 'Sell', 2800, 4, 3, true, 'assets/images/properties/kukatpally1.jpg'),

-- Mallapur Properties
('Farm House in Mallapur', 
 'Beautiful farm house with garden', 
 35000000, 'Mallapur', 'Farm House', 'Lease', 4000, 3, 3, true, 'assets/images/properties/mallapur1.jpg'),

-- Hi-Tech City Properties
('Office Space in Hi-Tech City', 
 'Ready to move office space', 
 45000000, 'Hi-Tech City', 'Commercial', 'Lease', 5000, NULL, 2, true, 'assets/images/properties/hitech1.jpg'),

-- Habsiguda Properties
('Residential Plot in Habsiguda',
 'HMDA approved residential plot',
 8000000, 'Habsiguda', 'Plot', 'Sell', 1800, NULL, NULL, false, 'assets/images/properties/habsiguda1.jpg'),

-- Jubilee Hills Properties
('Luxury Villa in Jubilee Hills', 
 'Premium 5BHK villa with swimming pool', 
 55000000, 'Jubilee Hills', 'Villa', 'Sell', 5500, 5, 5.5, true, 'assets/images/properties/jubileehills1.jpg'),

-- Secunderabad Properties
('Apartment in Secunderabad',
 'Well-maintained 3BHK apartment',
 12000000, 'Secunderabad', 'Apartment', 'Buy', 1600, 3, 2, false, 'assets/images/properties/secunderabad1.jpg'),

-- Banjara Hills Properties
('Elite Villa in Banjara Hills',
 'Luxury 5BHK villa with modern amenities',
 65000000, 'Banjara Hills', 'Villa', 'Sell', 6000, 5, 5.5, true, 'assets/images/properties/banjarahills1.jpg'),

-- Manikonda Properties
('Farm Land in Manikonda',
 'Agricultural land with bore well',
 15000000, 'Manikonda', 'Farm Land', 'Sell', 43560, NULL, NULL, false, 'assets/images/properties/manikonda1.jpg');

-- Insert additional images for properties
INSERT INTO property_images (property_id, url) VALUES 
(1, 'assets/images/properties/gachibowli1.jpg'),
(1, 'assets/images/properties/gachibowli2.jpg'),
(2, 'assets/images/properties/shamshabad1.jpg'),
(3, 'assets/images/properties/kukatpally1.jpg'),
(4, 'assets/images/properties/mallapur1.jpg'),
(5, 'assets/images/properties/hitech1.jpg'),
(6, 'assets/images/properties/habsiguda1.jpg'),
(7, 'assets/images/properties/jubileehills1.jpg'),
(7, 'assets/images/properties/jubileehills2.jpg'),
(8, 'assets/images/properties/secunderabad1.jpg'),
(9, 'assets/images/properties/banjarahills1.jpg'),
(9, 'assets/images/properties/banjarahills2.jpg'),
(10, 'assets/images/properties/manikonda1.jpg');

-- Insert sample ventures data
INSERT INTO ventures (
    title, description, location, venture_type, price, area_size, image_url
) VALUES 
('Open Plots in Gachibowli', 'Premium plots for sale near Gachibowli', 'Gachibowli', 'Open Plots', 2500000, 400, 'assets/images/ventures/gachibowli_plots.jpg'),
('Villa Projects in Kukatpally', 'Luxurious villas for sale', 'Kukatpally', 'Villa Projects', 50000000, 3500, 'assets/images/ventures/villa_project.jpg'),
('Farm Lands in Shamshabad', 'Agricultural land for investment', 'Shamshabad', 'Farm Lands', 1500000, 6000, 'assets/images/ventures/farm_land.jpg');